package perpus;

public interface peminjaman {
    void pinjamBuku(String judul);
    void kembalikanBuku(String judul);
}
